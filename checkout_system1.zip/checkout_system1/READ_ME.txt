//SuperMarket Checkout System using c++//

runnig method - open the 'main.c++' source code file in ide/compiler(eg:codeblocks) and build/run from it.

Options

  i    -  display all the available items in the store(given in the project),with it's name,barcode and price.

  f    - finish adding items and display the total amount to be paid,more cash needed and balance to return

  y    - clear the display,clear the array.it jump to next customer's billing(loop the above mentioned)

  n    - quit from the program(ends the program with a greating)

  x    - to exit without purchasing


Usage:

  enter the barcodes of items to add items into the cart,to add quantity of item,type the barcode again as much quantity you
wants.after adding items enter 'f' to get total and options with it,and continue to next customer or quit from the program by
entering 'y' or 'n'

Note-user can use both capital and small letters in this program
            eg: 'i' and/or 'I' display all the items available