//welcome to my source code
#include <iostream>
#include <stdlib.h>
#include <vector>
#include <cstring>

using namespace std;

void display(struct items *item);//to display all items
void displayItem(struct items *item);//to display selected items

//just a tip to add quantity
void print()
{
    cout << "\n[!]Type the barcode again to add quantity of item" << endl;
    cout << "--------------------"<<endl;
}

//function to create welcome screen
void entry()
{
    cout << "********************************************************\n";
    cout << "*    WELCOME TO HERTS SUPERMARKET CHECKOUT SYSTEM      *\n";
    cout << "* Scan the barcode or mannually type the bracode ID    *\n";
    cout << "********************************************************\n";
    cout << "\n(: WELCOME :)" << endl;
}

//structure declaration
struct items
{
    char name[50];
    string bcode;
    float price;
};

int main()
{
    //variable declarations
    float sum=0, cash_rcvd, balance, more_needed, total;
    string barcode;
    string next;
    vector < float > arr;

        //declaring items
    struct items milk;//1
    struct items bread;//2
    struct items chocolate;//3
    struct items towel;//4
    struct items toothpaste;//5
    struct items soap;//6
    struct items pen;//7
    struct items biscuits;//8
    struct items lamp;//9
    struct items battery;//10

    //assigning values of items in structure
    strcpy(milk.name, "milk");
    milk.price = 10.50;
    milk.bcode = "0120001";

    strcpy(bread.name, "bread");
    bread.price = 5.50;
    bread.bcode = "0120002";


    strcpy(chocolate.name, "chocolate");
    chocolate.price = 8.00;
    chocolate.bcode = "0120003";

    strcpy(towel.name, "towel");
    towel.price = 12.10;
    towel.bcode = "0120004";

    strcpy(toothpaste.name, "toothpaste");
    toothpaste.price = 6.75;
    toothpaste.bcode = "0120005";

    strcpy(soap.name, "soap");
    soap.price = 5.20;
    soap.bcode = "0120006";

    strcpy(pen.name, "pen");
    pen.price = 2.00;
    pen.bcode = "0120007";

    strcpy(biscuits.name, "biscuits");
    biscuits.price = 4.45;
    biscuits.bcode = "0120008";

    strcpy(lamp.name, "lamp");
    lamp.price = 20.50;
    lamp.bcode = "0120009";

    strcpy(battery.name, "battery");
    battery.price = 10.00;
    battery.bcode = "0120010";

    entry();//welcome screen function

    //main loop
    for(int i=0;i<20;i++)
    {
        cout << "\nEnter Barcode(Type 'f' to finish / Type 'i' to display available items):";
        cin >> barcode;
        if(barcode == "0120001")
        {
            arr.push_back(10.50);
            displayItem(&milk);
            print();

        }
        else if(barcode == "0120002")
        {

            arr.push_back(5.50);
            displayItem(&bread);
            print();
        }
        else if(barcode == "0120003")
        {
            arr.push_back(8.00);
            displayItem(&chocolate);
            print();
        }
        else if(barcode == "0120004")
        {
            arr.push_back(12.10);
            displayItem(&towel);
            print();
        }
        else if(barcode == "0120005")
        {
            arr.push_back(6.75);
            displayItem(&toothpaste);
            print();

        }
        else if(barcode == "0120006")
        {
            arr.push_back(5.20);
            displayItem(&soap);
            print();

        }
        else if(barcode == "0120007")
        {
            arr.push_back(2.00);
            displayItem(&pen);
            print();

        }
        else if(barcode == "0120008")
        {
            arr.push_back(4.45);
            displayItem(&biscuits);
            print();
        }
        else if(barcode == "0120009")
        {
            arr.push_back(20.50);
            displayItem(&lamp);
            print();
        }
        else if(barcode == "0120010")
        {
            arr.push_back(10.00);
            displayItem(&battery);
            print();

        }
        //to display all available items
        else if(barcode == "i" || barcode == "I")
        {
            display(&milk);
            display(&bread);
            display(&chocolate);
            display(&towel);
            display(&toothpaste);
            display(&soap);
            display(&pen);
            display(&biscuits);
            display(&lamp);
            display(&battery);

        }

        else if(barcode == "f" || barcode == "F")
        {
            if(arr.size() >= 1)
            {
                for(float j=0;j<arr.size();j++)
                {
                    sum += arr[j];
                }
            }
            //to check whether your cart is empty or not
            if(arr.size() < 1)
            {
                cout << "\n";
                cout << "[!]Your cart is empty! please add items to checkout.." << endl;
                cout << "[!]Type 'x' to exit without purchasing.." << endl;
                continue;
            }

            //details of purchassing
            cout << "\nTotal items:" << arr.size() << endl;
            cout << "Total price :"<< char(156) << sum;//where 156 is the ASCII code of the � sign,the � sign is not being recognised by the compiler.
            cout << "\n";
            total = sum; //assigning a variable (total) to 'sum' to use later

            //calculations an loop for settle payment and bill printing
            for(int k=0;k<15;k++)
            {
                cout << "cash recived:" << char(156);
                cin >> cash_rcvd;

                if(cash_rcvd == sum)
                {
                   cout << "\nSettlement Success!" << endl;
                   cout << "\n----------------RECEIPT-----------------"<<endl;
                   cout << "Total items :"<< arr.size();
                   cout << "\t\tAmount paid:" << char(156) << total;
                   cout<<"\n";
                   break;
                }
                else if(cash_rcvd < sum)
                {
                    more_needed = sum - cash_rcvd;
                    cout << "more needed:" << char(156) << more_needed << endl;
                    sum = sum - cash_rcvd;
                }
                else if(cash_rcvd >= sum)
                {
                    balance = cash_rcvd - sum;
                    cout << "Change given:" << char(156) << balance << endl;
                    cout << "\nSettlement Success!"<< endl;

                    cout << "\n----------------RECEIPT-----------------"<<endl;
                    cout << "Total items :"<< arr.size();
                    cout << "\t\tAmount paid:" << total;
                    cout<<"\n";
                    break;
                }
                else{
                    cout << "Unexpected Error...try again";
                    continue;
                }
            }

            //to restart the program for next customers
            for(int n=0;n<10;n++)
            {
                cout << "\nNext Customer? (y/n):";
                cin >> next;
                if(next == "y" || next == "Y")
                {
                    system("cls");
                    entry();
                    sum=0;
                    arr.clear();
                    break;

                }
                else if(next == "n" || next == "N")
                {
                    cout << "****************************************************"<<endl;
                    cout << "*Thank you for shopping with us,HAVE A GOOD DAY :) *"<<endl;
                    cout << "****************************************************" << endl;
                    break;
                }
                else
                {
                    cout << "\n[!]Try Again(Type 'y' for Yes or 'n' for No):";
                }
            }
        }
        //to exit without purchasing
        else if(barcode == "x" || barcode == "X")
        {
            cout << "\nTHANK YOU FOR VISTING OUR SHOP...BYE"<<endl;
            cout << "\n";
            break;

        }
        else
        {
            cout << "\n[!]Item not found\n";//if you eneter a item that is not available

        }

        if(next == "n" || next == "N")//to exit if no more customers in line
        {
            break;
        }

    }


    return 0;
}

void displayItem(struct items *item)//this function print the item according to the item barcode
{
    cout << "\n";
    cout << "Item added to cart"<<endl;
    cout << "--------------------"<<endl;
    cout << "Item :" << item->name << endl;
    cout << "Price: "<< char(156) << item->price << endl;

}
void display(struct items *item)//this function display all items when i is entered
{

    cout << "--------------------"<<endl;
    cout << "Barcode :" << item->bcode << endl;
    cout << "Item :" << item->name << endl;
    cout << "Price: "<< char(156) << item->price << endl;
    cout << "--------------------"<<endl;
}

//END---THANK YOU
